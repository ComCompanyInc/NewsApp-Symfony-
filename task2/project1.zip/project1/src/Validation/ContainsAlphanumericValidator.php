<?php

namespace App\Validation;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

/**
 * Класс валидации формы
 */
class ContainsAlphanumericValidator extends ConstraintValidator
{
    /**
     * метод проверки формы на введенные в форму данные
     * @param mixed $value
     * значения всех полей формы
     * @param Constraint $constraint
     * @return void
     */
    public function validate(mixed $value, Constraint $constraint): void
    {
        dump($value);

        $firstTeam = $value->getFirstTeam();
        $secondTeam = $value->getSecondTeam();

        dump($firstTeam);
        dump($secondTeam);

        if($firstTeam == $secondTeam)
        {
            $this->falied($constraint);
        }
    }

    /**
     * отправляет сообщение о некорректности формы
     * @param Constraint $constraint
     * @return void
     */
    private function falied(Constraint $constraint)
    {
        $this->context->buildViolation($constraint->message)
            ->addViolation();
    }
}