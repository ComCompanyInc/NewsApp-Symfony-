<?php

namespace App\Validation;

use Symfony\Component\Validator\Constraint;

#[\Attribute]
class ContainsAlphanumeric extends Constraint
{
    public string $message = 'Ошибка: команды не могут повторяться!';

    public function validatedBy(): string
    {
        return \get_class($this).'Validator';
    }

    public function getTargets(): array|string
    {
        return self::CLASS_CONSTRAINT;
    }
}