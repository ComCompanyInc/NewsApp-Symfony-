<?php

namespace App\Entity;

use App\Repository\MatchesRepository;
use App\Validation\ContainsAlphanumeric;
use App\Validation\ContainsAlphanumericValidator;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: MatchesRepository::class)]
#[ContainsAlphanumeric] //подключение класса с валидацией к форме
class Matches
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(nullable: true)]
    private ?int $numberOfGoalsFirstTeam = null;

    #[ORM\Column(nullable: true)]
    private ?int $numberOfGoalsSecondTeam = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date = null;

    #[ORM\ManyToOne(inversedBy: 'matches')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Tour $tour = null;

    #[ORM\ManyToOne(inversedBy: 'matches')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Team $firstTeam = null;

    #[ORM\ManyToOne(inversedBy: 'matches')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Team $secondTeam = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumberOfGoalsFirstTeam(): ?int
    {
        return $this->numberOfGoalsFirstTeam;
    }

    public function setNumberOfGoalsFirstTeam(?int $numberOfGoalsFirstTeam): static
    {
        $this->numberOfGoalsFirstTeam = $numberOfGoalsFirstTeam;

        return $this;
    }

    public function getNumberOfGoalsSecondTeam(): ?int
    {
        return $this->numberOfGoalsSecondTeam;
    }

    public function setNumberOfGoalsSecondTeam(?int $numberOfGoalsSecondTeam): static
    {
        $this->numberOfGoalsSecondTeam = $numberOfGoalsSecondTeam;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): static
    {
        $this->date = $date;

        return $this;
    }

    public function getTour(): ?Tour
    {
        return $this->tour;
    }

    public function setTour(?Tour $tour): static
    {
        $this->tour = $tour;

        return $this;
    }

    public function getFirstTeam(): ?Team
    {
        return $this->firstTeam;
    }

    public function setFirstTeam(?Team $firstTeam): static
    {
        $this->firstTeam = $firstTeam;

        return $this;
    }

    public function getSecondTeam(): ?Team
    {
        return $this->secondTeam;
    }

    public function setSecondTeam(?Team $secondTeam): static
    {
        $this->secondTeam = $secondTeam;

        return $this;
    }
}
