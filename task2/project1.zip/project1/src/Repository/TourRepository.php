<?php

namespace App\Repository;

use App\Entity\Tour;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Tour>
 */
class TourRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Tour::class);
    }

    //    /**
    //     * @return Tour[] Returns an array of Tour objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('t')
    //            ->andWhere('t.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('t.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Tour
    //    {
    //        return $this->createQueryBuilder('t')
    //            ->andWhere('t.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }

    /**
     * генерирует двумерный массив для вывода в турнирную таблицу по номеру тура и ID турнира
     * @param int $tournamentId
     * ID турнира
     * @param int $tourNumber
     * номер тура
     * @param array $matches
     * массив сущностей всех матчей
     * @return array
     * возвращает двумерный массив с результатом тура
     */
    public function getTourByTournamentId(int $tournamentId, int $tourNumber, array $matches): array
    {
        $firstTeam = null;
        $secondTeam = null;
        $firstScore = 0;
        $secondScore = 0;
        $date = null;

        $result = [];

            for ($i = 0; $i < count($matches); $i++) {
                dump($tournamentId.' = '.$matches[$i]->getTour()->getTournament()->getId() .' tournament');
                dump($tourNumber.' = '.$matches[$i]->getTour()->getNumber() .' tour');

                if(($tournamentId == $matches[$i]->getTour()->getTournament()->getId()) && ($tourNumber == $matches[$i]->getTour()->getNumber())) {
                    $result[$i][0] = $matches[$i]->getDate();
                    $result[$i][1] = $matches[$i]->getFirstTeam()->getName();
                    $result[$i][2] = $matches[$i]->getNumberOfGoalsFirstTeam();
                    $result[$i][3] = $matches[$i]->getNumberOfGoalsSecondTeam();
                    $result[$i][4] = $matches[$i]->getSecondTeam()->getName();
                }
            }

        return $result;
    }
}
