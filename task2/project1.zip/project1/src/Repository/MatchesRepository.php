<?php

namespace App\Repository;

use App\Entity\Matches;
use App\Entity\Team;
use App\Entity\Tour;
use App\Entity\Tournament;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\Validator\Constraints\Date;

/**
 * @extends ServiceEntityRepository<Matches>
 */
class MatchesRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Matches::class);
    }

    //    /**
    //     * @return Matches[] Returns an array of Matches objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('m')
    //            ->andWhere('m.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('m.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Matches
    //    {
    //        return $this->createQueryBuilder('m')
    //            ->andWhere('m.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }

    /**
     * метод с запросом на данные для подсчета турнирной таблицы
     * @return array
     * Возвращает массив обьектов матча
     */
    public function tournamentCounting(): array
    {
        $query = $this->createQueryBuilder('m')->select('m')
            ->innerJoin(Team::class, 't1', 'WITH', 't1.id = m.firstTeam')
            ->innerJoin(Team::class, 't2', 'WITH', 't2.id = m.secondTeam')
            ->innerJoin(Tour::class, 'tour', 'WITH', 'tour.id = m.tour')
            ->innerJoin(Tournament::class, 'tournament', 'WITH', 'tournament.id = tour.tournament')
            ->getQuery();

        return $query->getResult();
    }
}