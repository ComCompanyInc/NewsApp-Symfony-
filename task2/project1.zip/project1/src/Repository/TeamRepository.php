<?php

namespace App\Repository;

use App\Entity\Team;
use ContainerCYvknNh\getConsole_ErrorListenerService;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Team>
 */
class TeamRepository extends ServiceEntityRepository
{

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Team::class);
    }

    //    /**
    //     * @return Team[] Returns an array of Team objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('t')
    //            ->andWhere('t.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('t.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Team
    //    {
    //        return $this->createQueryBuilder('t')
    //            ->andWhere('t.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }

    /**
     * Реализует выборку из полученного запроса (MatchesRepository->tournamentCounting()) который возвращает массив обьектов
     * @param int $idTeam
     * ID команды
     * @param array $matches
     * массив обьектов (MatchesRepository->tournamentCounting())
     * @param int $idTournament
     * ID турнира
     * @return array
     * возвращает массив с данными по выборке
     */
    public function countResults(int $idTeam, int $idTournament, array $matches): array
    {
        $wins = 0;
        $defeats = 0;
        $draws = 0;
        $getGoals = 0;
        $playedGames = 0;
        $missedGoals = 0;
        $name = null;

        $result = [];

        foreach ($matches as $match) {
            if($idTeam == $match->getFirstTeam()->getId()) {
                $name = $match->getFirstTeam()->getName();

                if($idTournament == $match->getTour()->getTournament()->getId()) {
                    $getGoals = $getGoals + $match->getNumberOfGoalsFirstTeam();
                    $playedGames = $playedGames + 1;
                    $missedGoals = $missedGoals + $match->getNumberOfGoalsSecondTeam();

                    if ($match->getNumberOfGoalsFirstTeam() > $match->getNumberOfGoalsSecondTeam()) {
                        $wins++;
                    } else if ($match->getNumberOfGoalsFirstTeam() < $match->getNumberOfGoalsSecondTeam()) {
                        $defeats++;
                    } else if ($match->getNumberOfGoalsFirstTeam() == $match->getNumberOfGoalsSecondTeam()) {
                        $draws++;
                    }
                }
            }
            else if($idTeam == $match->getSecondTeam()->getId())
            {
                $name = $match->getSecondTeam()->getName();

                if($idTournament == $match->getTour()->getTournament()->getId()) {
                    $getGoals = $getGoals + $match->getNumberOfGoalsSecondTeam();
                    $playedGames = $playedGames + 1;
                    $missedGoals = $missedGoals + $match->getNumberOfGoalsFirstTeam();

                    if ($match->getNumberOfGoalsFirstTeam() < $match->getNumberOfGoalsSecondTeam()) {
                        $wins++;
                    } else if ($match->getNumberOfGoalsFirstTeam() > $match->getNumberOfGoalsSecondTeam()) {
                        $defeats++;
                    } else if ($match->getNumberOfGoalsFirstTeam() == $match->getNumberOfGoalsSecondTeam()) {
                        $draws++;
                    }
                }
            }

            $scores = ($wins*3)+$draws;
        }

        $result = array
        (
            'name' => $name,
            'goals' => $getGoals,
            'missedGoals' => $missedGoals,
            'wins' => $wins,
            'defeats' => $defeats,
            'draws' => $draws,
            'scores' => $scores,
            'playedGames' => $playedGames
        );

        return $result;
    }
}
