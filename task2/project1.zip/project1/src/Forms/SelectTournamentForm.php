<?php

namespace App\Forms;

use App\Entity\Tournament;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Форма выбора турнира на странице турнира
 */
class SelectTournamentForm extends AbstractType
{
    function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder

            ->add('tournament', EntityType::class, [
                'label' => 'Турнир: ',
                'class' => Tournament::class,
                'choice_label' => 'name',
            ]);
    }

}