<?php

namespace App\Forms;

use App\Entity\Matches;
use App\Entity\Team;
use App\Entity\Tour;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Форма заполнения матча на странице заполнения
 */
class MatchForm extends AbstractType
{
    #[Assert\NotBlank] //подключение формы на проверку пустых полей
    function buildForm(FormBuilderInterface $builder, array $options): void
    {
            $builder
                ->add('firstTeam', EntityType::class, [
                    'label' => 'Первая команда: ',
                    'class' => Team::class,
                    'choice_label' => 'name',
                    'constraints' => [
                        new Assert\NotBlank(),
                    ],
                ])
                ->add('secondTeam', EntityType::class, [
                    'label' => 'Вторая команда: ',
                    'class' => Team::class,
                    'choice_label' => 'name',
                    'constraints' => [
                        new Assert\NotBlank(),
                    ],
                ])
                ->add('tour', EntityType::class, [
                    'label' => 'Выбор тура: ',
                    'class' => Tour::class,
                ])
                ->add('numberOfGoalsFirstTeam', IntegerType::class, [
                    'label' => 'количество забитых мячей первой команде: ',
                    'constraints' => [
                        new Assert\NotBlank()
                    ],
                ])
                ->add('numberOfGoalsSecondTeam', IntegerType::class, [
                    'label' => 'количество забитых мячей второй команде: ',
                    'constraints' => [
                        new Assert\NotBlank()
                    ],
                ])
                ->add('button', SubmitType::class, [
                    'label' => 'сохранить'
                ]);

    }


    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Matches::class,
        ]);
    }
}