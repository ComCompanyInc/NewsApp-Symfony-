<?php

namespace App\Forms;

use App\Entity\Tour;
use App\Repository\TourRepository;
use Doctrine\ORM\QueryBuilder;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Форма выбора тура на странице вывода туров
 */
class SelectTourForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $idTournament = $options['data'];

        $builder
            ->add('number', EntityType::class, [
                'label' => 'Выбор тура: ',
                'class' => Tour::class,

                'query_builder' => function (TourRepository $tr) use ($idTournament): QueryBuilder {
                    return $tr->createQueryBuilder('u')
                        ->where('u.tournament = :tournament')
                        ->setParameter('tournament', $idTournament);
                },

                'choice_label' => 'number'
            ]);
    }
}