<?php

namespace App\Forms;

use App\Entity\Tour;
use App\Entity\Tournament;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

//Форма заполнения тура на странице заполнения
class TourForm extends AbstractType
{
    function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder

            ->add('number', IntegerType::class, [
                'label' => 'Номер тура: '
            ])

            ->add('tournament', EntityType::class, [
                'label' => 'Турнир: ',
                'class' => Tournament::class,
                'choice_label' => 'name',
            ])

            ->add('button', SubmitType::class, [
                'label' => 'сохранить'
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Tour::class,
        ]);
    }
}