<?php

namespace App\Service;

use App\Repository\MatchesRepository;
use App\Repository\TeamRepository;
use App\Repository\TournamentRepository;
use ErrorException;

class ArrayCountingService
{
    private TeamRepository $teamRepository;
    private MatchesRepository $matchesRepository;
    private TournamentRepository $tournamentRepository;

    public function __construct(TeamRepository $teamRepository, MatchesRepository $matchesRepository, TournamentRepository $tournamentRepository)
    {
        $this->teamRepository = $teamRepository;
        $this->matchesRepository = $matchesRepository;
        $this->tournamentRepository = $tournamentRepository;
    }

    /**
     * Генерация двумерного массива по вычисляемым данным для заполнения таблицы
     * @return array
     * возвращает массив с вычисленными данными сортированный по количеству очков
     */
    public function arrayCount(string $tournament): array
    {
        $tournamentTable = [];

        $idTournament = $this->tournamentRepository->findOneBy(['name' => $tournament])->getId();

        //Заполнение массива данными
        $numTeams = $this->teamRepository->count();
        for ($i = 1; $i < $numTeams + 1; $i++) { //строки
            for ($j = 1; $j < 10; $j++) { //столбцы

                $arrayResult = $this->teamRepository->countResults($i, $idTournament, $this->matchesRepository->tournamentCounting(/*$idTournament*/));

                switch($j)
                {
                    case 2:
                        $tournamentTable[$i][$j] = $arrayResult['name'];
                        break;

                    case 3:
                        $tournamentTable[$i][$j] = $arrayResult['playedGames'];
                        break;

                    case 4:
                        $tournamentTable[$i][$j] = $arrayResult['scores'];
                        break;

                    case 5:
                        $tournamentTable[$i][$j] = $arrayResult['goals'];
                        break;

                    case 6:
                        $tournamentTable[$i][$j] = $arrayResult['missedGoals'];
                        break;

                    case 7:
                        $tournamentTable[$i][$j] = $arrayResult['wins'];
                        break;

                    case 8:
                        $tournamentTable[$i][$j] = $arrayResult['draws'];
                        break;

                    case 9:
                        $tournamentTable[$i][$j] = $arrayResult['defeats'];
                        break;
                    default:
                        $tournamentTable[$i][$j] = null;
                        break;
                }
            }
        }

        $tournamentTable = $this->sortArrayByKey($tournamentTable, 3); // сортировка по сыгранным матчам
        $tournamentTable = $this->sortArrayByKey($tournamentTable, 4); // сортировка по очкам

        $place = 0;

        $getLengthTeam = $this->teamRepository->count();
        for($i = 1; $i < $getLengthTeam+1; $i++) // вывод места комманды
        {
            if(isset($tournamentTable[$i][2])) {
                $place++;
                $tournamentTable[$i][1] = $place;
            }
        }

        return $tournamentTable;
    }

    /**
     * сортировка полученного массива по убыванию
     * @param $array
     * двумерный массив
     * @param int $key
     * ключ (индекс) столбца массива по которому производится сортировка по убыванию
     * @return array
     * возврат отсортированного массива
     */
    function sortArrayByKey(array $array, int $key): array
    {

            for ($l = 1; $l < count($array); $l++) { // цикл на все итерации сортировки массива

                for ($i = 1; $i < count($array); $i++) { //строки (цикл на одну итерацию сортировеи для всех элементов)
                    try {
                    if ($array[$i][$key] < $array[$i + 1][$key]) {
                        for ($j = 1; $j < 10; $j++) { // столбцы
                            $temp = $array[$i][$j];
                            $array[$i][$j] = $array[$i + 1][$j];
                            $array[$i + 1][$j] = $temp;
                        }
                    }
                    }catch (ErrorException)
                    {
                        continue;
                    }
                }
            }

        return $array;
    }
}