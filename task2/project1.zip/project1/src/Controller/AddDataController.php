<?php

namespace App\Controller;

use App\Entity\Matches;
use App\Entity\Team;
use App\Entity\Tour;
use App\Entity\Tournament;
use App\Forms\MatchForm;
use App\Forms\SelectTourForm;
use App\Forms\SelectTournamentForm;
use App\Forms\TeamForm;
use App\Forms\TourForm;
use App\Forms\TournamentForm;
use App\Repository\MatchesRepository;
use App\Repository\TeamRepository;
use App\Repository\TourRepository;
use App\Service\ArrayCountingService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AddDataController extends AbstractController
{
    private EntityManagerInterface $entityManager;
    private TeamRepository $teamRepository;
    private ArrayCountingService $arrayCounting;

    private MatchesRepository $matchesRepository;
    private TourRepository $tourRepository;

    function __construct(EntityManagerInterface $entityManager, TeamRepository $teamRepository, ArrayCountingService $arrayCounting, MatchesRepository $matchesRepository, TourRepository $tourRepository)
    {
        $this->entityManager = $entityManager;
        $this->teamRepository = $teamRepository;
        $this->arrayCounting = $arrayCounting;
        $this->matchesRepository = $matchesRepository;
        $this->tourRepository = $tourRepository;
    }

    /**
     * Контроллер с домашней страницей (подсчет турнирной таблицы с сортировкой)
     * @param Request $response
     * @return Response
     */
    #[Route('/home', name: 'home')]
    function homeAction(Request $response): Response
    {
        $selectForm = $this->createForm(SelectTournamentForm::class/*, $tour*/);

        $selectForm->handleRequest($response);

        $tableData = [
            'header' => ['место команды', 'Название команды', 'Количество сыгранных матчей',
                'Количество очков', 'Количество забитых мячей', 'Количество пропущеных мячей',
                'Количество побед', 'Количество ничьих', 'Количество поражений'],
            'rows' => []
        ];

        return $this->render('home/home.html.twig', [
                'selectTournament' => $selectForm,
                'table' => $tableData,
            ]);
    }

    /**
     * Контроллер с добавлением матчей команд турниров и туров
     * @param Request $request
     * @return Response
     * @throws \Exception
     */
    #[Route('/home/addMatch', name: 'addMatch')]
    function addMatchAction(Request $request): Response
    {
        $tournament = new Tournament();
        $tournamentForm = $this->createForm(TournamentForm::class, $tournament);

        $tournamentForm->handleRequest($request);

        if ($tournamentForm->isSubmitted() && $tournamentForm->isValid())
        {
            $dataTournament = $tournamentForm->getData();
            $this->entityManager->persist($dataTournament);
            $this->entityManager->flush();
        }

        $tour = new Tour();
        $tourForm = $this->createForm(TourForm::class, $tour);

        $tourForm->handleRequest($request);

        if ($tourForm->isSubmitted() && $tourForm->isValid())
        {
            $dataTour = $tourForm->getData();

            $tour->setTournament($dataTour->getTournament());
            $tour->setNumber($dataTour->getNumber());

            $this->entityManager->persist($tour);
            $this->entityManager->flush();
        }

        $team = new Team();
        $teamForm = $this->createForm(TeamForm::class, $team);

        $teamForm->handleRequest($request);

        // кнопка сохранения формы имен команд
        if($teamForm->isSubmitted() && $teamForm->isValid())
        {
            $dataName = $teamForm->getData();
            $this->entityManager->persist($dataName);
            $this->entityManager->flush();
        }

        $matches = new Matches();

        $matchForm = $this->createForm(MatchForm::class, $matches);

        $matchForm->handleRequest($request);

        //кнопка сохранения матча
        if($matchForm->isSubmitted() && $matchForm->isValid())
        {
            $dataMatch = $matchForm->getData();

            //ID игравших комманд
            $matches->setFirstTeam($dataMatch->getFirstTeam());
            $matches->setSecondTeam($dataMatch->getSecondTeam());

            $matches->setTour($dataMatch->getTour());

            $matches->setNumberOfGoalsFirstTeam($dataMatch->getNumberOfGoalsFirstTeam());
            $matches->setNumberOfGoalsSecondTeam($dataMatch->getNumberOfGoalsSecondTeam());
            $matches->setDate(new \DateTime(date("Y-m-d H:i:s")));

            $this->entityManager->persist($matches);
            $this->entityManager->flush();
        }

        $allTournaments = $this->entityManager->getRepository(Tournament::class)->findAll();
        $allTours = $this->entityManager->getRepository(Tour::class)->findAll();
        $allTeams = $this->teamRepository->findAll();
        $allMatches = $this->entityManager->getRepository(Matches::class)->findAll();

        return $this->render('addMatch/addMatch.html.twig', [
            'addTournament' => $tournamentForm,
            'addTour' => $tourForm,
            'addNameTeam' => $teamForm,
            'addMatchForm' => $matchForm,
            'tournaments' => $allTournaments,
            'tours' => $allTours,
            'teams' => $allTeams,
            'matches' => $allMatches,
        ]);
    }

    /**
     * Контроллер на удаление команд (для ajax запросов)
     * @param int $id
     * ID строчки на удаление
     * @return JsonResponse
     */
    #[Route('/team/delete/{id}', name: 'deleteTeam')]
    function deleteTeam(int $id): JsonResponse
    {
        $deleteData = $this->entityManager->getRepository(Team::class)->findOneBy(['id' => $id]);

        if($deleteData) {

            $this->entityManager->remove($deleteData);
            $this->entityManager->flush();

            return new JsonResponse(['message' => 'success deleted!'],200);
        } else {
            return new JsonResponse(503);
        }
    }

    /**
     * Контроллер для удаления турниров (для ajax запросов)
     * @param int $id
     * ID строчки на удаление
     * @return JsonResponse
     */
    #[Route('/tournament/delete/{id}', name: 'deleteTournament')]
    function deleteTournament(int $id): JsonResponse
    {
        $deleteData = $this->entityManager->getRepository(Tournament::class)->findOneBy(['id' => $id]);

        if($deleteData) {

            $this->entityManager->remove($deleteData);
            $this->entityManager->flush();

            return new JsonResponse(['message' => 'success deleted!'],200);
        } else {
            return new JsonResponse(503);
        }
    }

    /**
     * Контроллер для удаления туров (для ajax запросов)
     * @param int $id
     * ID строчки на удаление
     * @return JsonResponse
     */
    #[Route('/tour/delete/{id}', name: 'deleteTour')]
    function deleteTour(int $id): JsonResponse
    {
        $deleteData = $this->entityManager->getRepository(Tour::class)->findOneBy(['id' => $id]);

        if($deleteData) {

            $this->entityManager->remove($deleteData);
            $this->entityManager->flush();

            return new JsonResponse(['message' => 'success deleted!'],200);
        } else {
            return new JsonResponse(503);
        }
    }

    /**
     * Контроллер для удаления матчей (для ajax запросов)
     * @param int $id
     * ID строчки на удаление
     * @return JsonResponse
     */
    #[Route('/match/delete/{id}', name: 'deleteMatch')]
    function deleteMatch(int $id): JsonResponse
    {
        $deleteData = $this->entityManager->getRepository(Matches::class)->findOneBy(['id' => $id]);

        if($deleteData) {

            $this->entityManager->remove($deleteData);
            $this->entityManager->flush();

            return new JsonResponse(['message' => 'success deleted!'],200);
        } else {
            return new JsonResponse(503);
        }
    }

    /**
     * Контроллер для сортировки таблицы туров (для ajax запросов)
     * @param string $key
     * столбец с названием в таблице по которому нужно произвести сортировку (функционал кнопок в таблице 'сортировать')
     * @param string $tournamentSelection
     * Имя выбранного турнира
     * @return JsonResponse
     */
    #[Route('/home/sort/{key}/{tournamentSelection}', name: 'homeSort')]
    function homeSort(string $key, string $tournamentSelection): JsonResponse
    {

        $tournamentTable = $this->arrayCounting->arrayCount($tournamentSelection);

        switch($key) {
            case "Количество сыгранных матчей":
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 3);
                break;

            case 'Количество очков':
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 4);
                break;

            case 'Количество забитых мячей':
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 5);
                break;

            case 'Количество пропущеных мячей':
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 6);
                break;

            case 'Количество побед':
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 7);
                break;

            case 'Количество ничьих':
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 8);
                break;

            case 'Количество поражений':
                $sortArray = $this->arrayCounting->sortArrayByKey($tournamentTable, 9);
                break;

            default:
                return new JsonResponse(['message' => 'error (key = '.$key.')'],500);
        }

        $arrayForSending = [
            'header' => ['место команды', 'Название команды', 'Количество сыгранных матчей',
                'Количество очков', 'Количество забитых мячей', 'Количество пропущеных мячей',
                'Количество побед', 'Количество ничьих', 'Количество поражений'],
            'rows' => $sortArray
        ];

        $response = $this->render('home/homeTable.html.twig', [
            'table' => $arrayForSending]);

        return new JsonResponse(['message' => $response->getContent()], 200);
    }

    /**
     * Контроллер для перехода на страницу с таблицей туров по выбранному турниру
     * @param string $tournament
     * Имя турнира
     * @param Request $request
     * @return Response
     */
    #[Route('/tour/{tournament}', name:'tour')]
    function tourAction(string $tournament, Request $request): Response
    {
        $idTournament = (int)$this->entityManager->getRepository(Tournament::class)->findOneBy(['name' => $tournament])->getId();

        $selectedTourForm = $this->createForm(SelectTourForm::class, null, ['data' =>
            array($idTournament)
        ]);

        return $this->render('tour/tour.html.twig', [
            'selectedTourForm' => $selectedTourForm,
            'nameTour' => $tournament,
            'table' => []
        ]);
    }

    /**
     * Контроллер обновления таблицы туров по выпадающему списку выбора туров (для ajax запросов)
     * @param string $tournament
     * Название турнира
     * @param int $idTour
     * ID тура
     * @return JsonResponse
     */
    #[Route('tour/refresh/{tournament}/{idTour}', name: 'tourRefresh')]
    function refreshTourTable(string $tournament, int $idTour): JsonResponse
    {
        $tournamentId = $this->entityManager->getRepository(Tournament::class)->findOneBy(['name' => $tournament])->getId();

        $tourObject = $this->tourRepository->getTourByTournamentId(
            $tournamentId,
            $idTour,
            $this->matchesRepository->tournamentCounting()
        );

        $refreshArrayTable = [
            'header' => ['Дата', 'Хозяева', 'Счет хозяев',
        'Счет гостей', 'Гости'],
            'rows' => $tourObject
        ];

        $response =  $this->render('tour/tourTable.html.twig', [
            'table' => $refreshArrayTable
        ]);

        return new JsonResponse(['message' => $response->getContent()], 200);
    }
}